//
//  CRViewController.h
//  ChatRoom
//
//  Created by Melo Yao on 3/30/15.
//

#import <UIKit/UIKit.h>

@interface CRViewController : UIViewController

@end
