//
//  AppDelegate.h
//  SioChatDemo
//
//  Created by Melo Yao on 3/30/15.
//  Copyright (c) 2015 Melo Yao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

